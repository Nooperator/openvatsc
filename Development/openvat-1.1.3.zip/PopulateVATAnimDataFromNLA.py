import bpy

# ------------------------------------------------------------
# CONFIG
# ------------------------------------------------------------

START_FRAME = 1
GAP_FRAMES = 0

CLEAR_EXISTING_VAT_DATA = True
CLEAR_EXISTING_BAKE_TRACKS = True

BAKE_TRACK_NAME = "OpenVAT111_ActionBake"


# ------------------------------------------------------------
# HELPERS
# ------------------------------------------------------------

def get_action_manual_range(action):
    try:
        if hasattr(action, "frame_start") and hasattr(action, "frame_end"):
            start_frame = round(action.frame_start)
            end_frame = round(action.frame_end)
        elif hasattr(action, "frame_range"):
            start_frame = round(action.frame_range[0])
            end_frame = round(action.frame_range[1])
        else:
            return None, None, "frame range values are unavailable"
    except (TypeError, IndexError):
        return None, None, "manual frame range values are invalid"

    if end_frame < start_frame:
        return None, None, f"end frame {end_frame} is before start frame {start_frame}"

    return start_frame, end_frame, None


def action_targets_armature(action):
    if getattr(action, "id_root", None) == 'ARMATURE':
        return True

    return any(fc.data_path.startswith("pose.bones") for fc in action.fcurves)


def get_target_candidates():
    candidates = []

    def add_candidate(obj):
        if obj and obj not in candidates:
            candidates.append(obj)

    active = bpy.context.object
    add_candidate(active)

    for obj in bpy.context.selected_objects:
        add_candidate(obj)

    if active and active.type == 'MESH':
        for mod in active.modifiers:
            if mod.type == 'ARMATURE':
                add_candidate(mod.object)

    return candidates


def choose_action_target(action, candidates):
    if action_targets_armature(action):
        for obj in candidates:
            if obj and obj.type == 'ARMATURE':
                return obj
        return None

    active = bpy.context.object
    if active in candidates:
        return active

    return candidates[0] if candidates else None


def get_valid_action_items():
    valid_items = []
    skipped_actions = []
    candidates = get_target_candidates()

    for action in bpy.data.actions:
        start_frame, end_frame, skip_reason = get_action_manual_range(action)

        if skip_reason:
            skipped_actions.append({
                "name": action.name,
                "reason": skip_reason,
            })
            continue

        target = choose_action_target(action, candidates)
        if not target:
            skipped_actions.append({
                "name": action.name,
                "reason": "no compatible target object found",
            })
            continue

        valid_items.append({
            "action": action,
            "target": target,
            "source_start": start_frame,
            "source_end": end_frame,
        })

    valid_items.sort(key=lambda item: (
        item["source_start"],
        item["source_end"],
        item["action"].name,
    ))

    return valid_items, skipped_actions


def print_skipped_actions(skipped_actions):
    if not skipped_actions:
        return

    print(f"Skipped {len(skipped_actions)} Action(s):")
    for item in skipped_actions:
        print(f"  - {item['name']}: {item['reason']}")


def clear_vat_anim_data(scene):
    data = get_vat_anim_data(scene)

    if hasattr(data, "clear"):
        data.clear()
    else:
        while len(data) > 0:
            data.remove(0)


def add_vat_entry(scene, name, start_frame, end_frame):
    entry = get_vat_anim_data(scene).add()
    entry.name = name
    entry.start_frame = int(start_frame)
    entry.end_frame = int(end_frame)
    if hasattr(entry, "framerate"):
        fps_base = getattr(scene.render, "fps_base", 1.0) or 1.0
        entry.framerate = scene.render.fps / fps_base
    if hasattr(entry, "looping"):
        entry.looping = True
    return entry


def get_vat_anim_data(scene):
    if hasattr(scene, "openvat_111_anim_data"):
        return scene.openvat_111_anim_data
    if hasattr(scene, "vat_anim_data"):
        return scene.vat_anim_data
    raise RuntimeError("No VAT animation data collection is registered on the scene.")


def ensure_animation_data(obj):
    obj.animation_data_create()
    return obj.animation_data


def remove_existing_bake_tracks(targets):
    if not CLEAR_EXISTING_BAKE_TRACKS:
        return

    for target in targets:
        anim_data = target.animation_data
        if not anim_data:
            continue

        for track in list(anim_data.nla_tracks):
            if track.name == BAKE_TRACK_NAME:
                anim_data.nla_tracks.remove(track)


def get_or_create_bake_track(target):
    anim_data = ensure_animation_data(target)
    track = anim_data.nla_tracks.new()
    track.name = BAKE_TRACK_NAME
    track.mute = False
    track.lock = False
    return track


def make_nla_strip(track, item, timeline_start, timeline_end):
    action = item["action"]
    source_start = item["source_start"]
    source_end = item["source_end"]
    strip_end = max(timeline_end, timeline_start + 1)

    strip = track.strips.new(action.name, timeline_start, action)
    strip.frame_start = timeline_start
    strip.frame_end = strip_end
    strip.action_frame_start = source_start
    strip.action_frame_end = max(source_end, source_start + 1)
    strip.repeat = 1.0
    strip.scale = 1.0
    strip.blend_type = 'REPLACE'
    strip.extrapolation = 'NOTHING'
    return strip


def layout_actions_for_bake(scene, valid_items):
    tracks_by_target = {}
    cursor = START_FRAME
    laid_out_items = []

    remove_existing_bake_tracks({item["target"] for item in valid_items})

    for item in valid_items:
        target = item["target"]
        if target not in tracks_by_target:
            tracks_by_target[target] = get_or_create_bake_track(target)

        source_duration = item["source_end"] - item["source_start"]
        timeline_start = cursor
        timeline_end = cursor + source_duration

        make_nla_strip(tracks_by_target[target], item, timeline_start, timeline_end)

        ensure_animation_data(target).action = None

        laid_out_items.append({
            **item,
            "timeline_start": timeline_start,
            "timeline_end": timeline_end,
        })

        cursor = timeline_end + GAP_FRAMES + 1

    scene.frame_start = START_FRAME
    scene.frame_end = max(item["timeline_end"] for item in laid_out_items)

    return laid_out_items


# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------

scene = bpy.context.scene
valid_items, skipped_actions = get_valid_action_items()

if not valid_items:
    print_skipped_actions(skipped_actions)
    raise RuntimeError("No Actions with valid frame ranges and compatible targets found.")

laid_out_items = layout_actions_for_bake(scene, valid_items)

if CLEAR_EXISTING_VAT_DATA:
    clear_vat_anim_data(scene)

for item in laid_out_items:
    add_vat_entry(
        scene,
        item["action"].name,
        item["timeline_start"],
        item["timeline_end"],
    )

print_skipped_actions(skipped_actions)
print("Action-based VAT bake timeline complete.")
print(f"Created {len(laid_out_items)} VAT animation entries.")
print(f"Timeline range: {scene.frame_start} - {scene.frame_end}")
print(f"Created bake track '{BAKE_TRACK_NAME}' on:")
for target in sorted({item["target"] for item in laid_out_items}, key=lambda obj: obj.name):
    print(f"  - {target.name}")
